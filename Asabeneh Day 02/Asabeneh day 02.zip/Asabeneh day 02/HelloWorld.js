//Level 1
// N0. 1
var challenge = '30 Days Of JavaScript' ;
//NO, 2
console.log(challenge);
//NO. 3
console.log(challenge.length)
//NO. 4
console.log(challenge.toUpperCase())
//NO.5
console.log(challenge.toLowerCase())
//NO. 6
console.log(challenge.substr(0))
//NO. 7
console.log(challenge.substr(1,16))
//NO. 8
console.log(challenge.includes(script))
//NO. 9
console.log(challenge.split())
//NO. 10
console.log(challenge.split(' '))
//NO. 11
console.log(challenge.replace('JavaScript', 'Python'))
//NO. 12
console.log(challenge.charAt(15))  
//N0. 13
console.log(challenge.charCodeAt(8))
//N0. 14
console.log(challenge.indexOf(J))
//NO.15
console.log(challenge.lastIndexOf(a))
let position = 'You cannot end a sentence with because because because is a conjunction'
//NO. 16
console.log(position.indexOf(because))
//NO. 17
console.log(position.lastIndexOf(because))
//NO. 18
console.log(position.search(because))
//NO. 19
console.log(position.trim())
//NO. 20
console.log(challenge.startsWith(30))
//NO. 21
console.log(challenge.endsWith(javascript))
//NO. 22
console.log(challenge.match(a))
//NO. 23
console.log(challenge.concat("30" , "Days" , "Of" ,
 "JavaScript"))
 //NO. 24
console.log(challenge.repeat(2))

// level 2 Exercise
//N0.1
var quote1 = 'There is no exercise better for the heart than reaching down and lifting people up'
//NO. 2
let quote2 = "Love is not patronizing and charity isn't about pity, it is about love. Charity and love are the same -- with charity you give love, so don't just give money but reach out your hand instead."
// checking datatypes using typeof
//N0. 3
console.log(typeof "10" === 10); 
//N0. 4
let parsefloat = '9.8'
console.log(parseFloat==age)
console.log(typeof '10')
//N0. 5
let me = python
console.log(me.match(on))
let him = jargon
console.log(him.match(on))
//N0. 6
let jb="I hope this course is not full of jargon"
console.log(jb.match("jargon"))
//generatting random number
//N0. 7
let randomNum = Math.random()
let numBtnZeroAndHundred = randomNum * 111
console.log(numBtnZeroAndHundred)
//N0. 8
let numBtnFiftyAndHundred = randomNum * 100
console.log (numBtnFiftyAndHundred)
//N0. 9
let numBtnZeroAndTwoAndFiftyFive = randomNum * 255
console.log(numBtnZeroAndTwoAndFiftyFive)
//N0. 10
const char = 'JavaScript';
console.log(char[Math.floor(Math.random() * 3)]);
//NO. 11
console.log ('1/1/1/1/1')
console.log ('2/1/2/4/8')
console.log ('3/1/3/9/27')
console.log ('4/1/4/16/27')
console.log ('5/1/5/25/125')
//N0. 12
let final = 'You cannot end a sentence with because because because is a conjunction'
console.log(final.substr(' because because because '))
//level 3
//No. 1
let luv = 'Love is the best thing in this world. Some found their love and some are still looking for their love.'
console.log(luv.match(love))
//N0. 2
let next = 'You cannot end a sentence with because because because is a conjunction'
console.log(next.match(because))
//N0. 3
const sentence = '%I $am@% a %tea@cher%, &and& I lo%#ve %te@a@ching%;. The@re $is no@th@ing; &as& mo@re rewarding as educa@ting &and& @emp%o@weri@ng peo@ple. ;I found tea@ching m%o@re interesting tha@n any ot#her %jo@bs. %Do@es thi%s mo@tiv#ate yo@u to be a tea@cher!? %Th#is 30#Days&OfJavaScript &is al@so $the $resu@lt of &love& of tea&ching'
console.log(sentence.repeat(teaching))
//N0. 4
const annualIncome = 'He earns 5000 euro from salary per month, 10000 euro annual bonus, 15000 euro online courses per month.';
const annualIncomeRegex = annualIncome.match(/\d+/g);
const totalAnnualIncome = 0;











